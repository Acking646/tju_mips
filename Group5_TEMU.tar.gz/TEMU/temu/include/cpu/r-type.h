#ifndef __RTYPE_H__
#define __RTYPE_H__

make_helper(and);
make_helper(add);
make_helper(addu);
make_helper(sll);
make_helper(sllv);
make_helper(srav);

#endif

#ifndef __TEMU_H__
#define __TEMU_H__

#include "common.h"
#include "memory.h"
#include "reg.h"

#endif
